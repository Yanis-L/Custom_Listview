package com.example.custom_listview;

public class Contact {
    public String name;
    public String phoneNo;
    public String imageUri;

    public Contact(String name, String phoneNo, String imageUri) {
        this.name = name;
        this.phoneNo = phoneNo;
        this.imageUri = imageUri;
    }
}